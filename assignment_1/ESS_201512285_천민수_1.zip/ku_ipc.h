#ifndef KU_IPC_H
# define KU_IPC_H

# define KUIPC_MAXMSG 20
# define KUIPC_MAXVOL 2720
# define KU_IPC_CREAT	0x01
# define KU_IPC_EXCL	0x02
# define KU_IPC_NOWAIT	0x04
# define KU_MSG_NOERROR	0x08

#endif
